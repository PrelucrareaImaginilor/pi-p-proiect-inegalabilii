from contextlib import nullcontext

import cv2
import sys
import os
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from IPython.display import HTML
import urllib

video_input_file_name = "volley1.mp4"

def drawRectangle(frame, bbox):
    p1 = (int(bbox[0]), int (bbox[1]))
    p2 = (int (bbox[0] + bbox[2]), int (bbox[1] + bbox[3]))
    cv2.rectangle(frame, p1, p2, (255,0,0), 2, 1) # (frmae, colt dreapta sus, colt stanga jos, culoare, grosime, tipul liniei)

def displayRectangle(frame, bbox):
    plt.figure(figsize=(20,10))
    frameCopy = frame.copy()
    drawRectangle(frameCopy, bbox)
    frameCopy = cv2.cvtColor(frameCopy, cv2.COLOR_RGB2BGR)
    plt.imshow(frameCopy); plt.axis('off')

def drawText(frame, txt, location, color=(255, 255, 255)):
    cv2.putText(frame, txt, location, cv2.FONT_HERSHEY_SIMPLEX, 1, color, 3)


# Set up tracker
tracker_types = ['BOOSTING', 'MIL', 'KCF', 'CSRT', 'TLD', 'MEDIANFLOW', 'GOTURN', 'MOSSE']

# Change the index to change the tracker type
tracker_type = tracker_types[2]


if tracker_type == 'KCF':
    tracker = cv2.TrackerKCF_create()
    tracker2 = cv2.TrackerKCF_create()
    tracker3 = cv2.TrackerKCF_create()
    tracker4 = cv2.TrackerKCF_create()

# Read video
video = cv2.VideoCapture(video_input_file_name)
ok, frame = video.read()


# Exit if video not opened
if not video.isOpened():
    print("Could not open video")
    sys.exit()
else:
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))

video_output_file_name = 'volley-' + tracker_type + '.mp4'
video_out = cv2.VideoWriter(video_output_file_name, cv2.VideoWriter_fourcc(*'mp4v'), 10, (width, height))

#CLIP1:
bbox1 = (250, 400, 150, 150)
bbox2 = (550, 350, 150, 150)
bbox3 = (500, 500, 150, 150)
bbox4 = (830, 480, 200, 200)

#CLIP2:
#bbox1 = (450, 800, 200, 200)
#box2 = (670, 250, 150, 150)
#bbox3 = (1000, 250, 150, 150)
#bbox4 = (850, 650, 200, 200)

displayRectangle(frame, bbox1)
displayRectangle(frame, bbox2)
displayRectangle(frame, bbox3)
displayRectangle(frame, bbox4)

ok = tracker.init(frame, bbox1)
ok2 = tracker2.init(frame, bbox2)
ok3 = tracker3.init(frame, bbox3)
ok4 = tracker4.init(frame, bbox4)
while True:
    ok, frame = video.read()
    if not ok:
        break

    # Start timer
    timer = cv2.getTickCount()

    # Update tracker
    ok, bbox1 = tracker.update(frame)
    ok2, bbox2 = tracker2.update(frame)
    ok3, bbox3 = tracker3.update(frame)
    ok4, bbox4 = tracker4.update(frame)

    # Calculate Frames per second (FPS)
    fps = cv2.getTickFrequency() / (cv2.getTickCount() - timer)

    # Draw bounding box
    if ok:
        drawRectangle(frame, bbox1)
    else:
        drawText(frame, "Tracking failure detected (Tracker 1)", (80, 140), (0, 0, 255))
    if ok2:
        drawRectangle(frame, bbox2)
    else:
        drawText(frame, "Tracking failure detected (Tracker 2)", (80, 200), (0, 0, 255))
    if ok3:
        drawRectangle(frame, bbox3)
    else:
        drawText(frame, "Tracking failure detected (Tracker 3)", (80, 200), (0, 0, 255))
    if ok4:
        drawRectangle(frame, bbox4)
    else:
        drawText(frame, "Tracking failure detected (Tracker 4)", (80, 200), (0, 0, 255))

    # Display Info
    drawText(frame, tracker_type + " Tracker", (80, 60))
    drawText(frame, "FPS : " + str(int(fps)), (80, 100))

    # Show frame in a window
    resized_frame = cv2.resize(frame, (1200, 600))  # Dimensiune dorită
    cv2.imshow("Tracking", resized_frame)

    # Write frame to video
    video_out.write(frame)

    # Exit if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


# Cleanup
video.release()
video_out.release()
cv2.destroyAllWindows()

